# Party World — tiny multiplayer 3D hangout

A deliberately small first prototype: one shared outdoor lobby, simple avatars, WASD movement, live text chat, and an AI host panel.

## Run it on your computer

1. Install **Node.js LTS** from https://nodejs.org/
2. Unzip this folder.
3. Open a terminal inside the `party-world` folder.
4. Run:

   ```bash
   npm install
   ```

5. Start the game:

   ```bash
   npm run dev
   ```

6. Open the local address Vite prints (normally `http://localhost:5173`).
7. Open the same address in another browser tab and choose another name to test multiplayer.

## AI chat

The world and multiplayer chat work without an AI key. Without a key, the AI Host shows a demo response explaining how to enable it.

To enable real AI replies:

1. Create an API key in your OpenAI developer account.
2. Copy `.env.example` to a new file named `.env`.
3. Put your key after `OPENAI_API_KEY=`.
4. Set `OPENAI_MODEL` to a model available to your API project.
5. Restart `npm run dev`.

The key stays on the server and is never sent to the browser. API usage is billed separately by the API provider.

## Controls

- WASD or arrow keys: move
- Enter: focus world chat
- Click AI Host: open AI conversation

## What this prototype does not include yet

- Public internet hosting / invite links
- Accounts, persistence or moderation tools
- Voice chat
- Mobile touch controls
- Advanced collision, animations or a full map
- AI characters walking around in the world

This is a first playable foundation, not a finished public service. For friends to join from different homes, run `npm run build` and deploy this Node server (which serves the built `dist` folder) to a host that supports persistent WebSocket connections, then share the public site address.

## Stack

- Three.js for the 3D scene
- Node.js + Express for the server
- Socket.IO for real-time player movement and chat
- OpenAI Responses API for optional AI chat

The multiplayer server is intentionally simple. For a larger game with rooms, matchmaking and automatic state synchronisation, Colyseus is a sensible next step: https://docs.colyseus.io/


## Basic chat moderation

The server blocks common spellings and simple obfuscations of a racist slur. A player who sends a matching chat message is disconnected and their IP address is added to the server's ban list. Later connections from that IP are rejected. The ban list is stored in `server/data/ip-bans.json` locally; do not commit this file because it contains visitor IP addresses.

**Limitations:** IP bans can affect other people sharing the same Wi-Fi/network, and they can be bypassed with a VPN, mobile-data change, or dynamic IP. The free Render filesystem is ephemeral, so this file may be lost on redeploy/restart. For durable moderation, add accounts and a persistent database, plus report/mute tools and human review. The text matcher is not perfect and may miss obfuscated variants.
